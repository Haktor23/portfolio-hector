import React, { useState, useRef, useEffect } from 'react';
import { sendMessageToAI } from '../services/geminiService';
import { ChatMessage } from '../types';

const AIChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: 'Iniciando sistema... Soy el asistente de Hector. ¿En qué te puedo ayudar hoy?',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    const responseText = await sendMessageToAI(userMsg.text, history);

    const aiMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, aiMsg]);
    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none">
      {/* Chat Window */}
      <div 
        className={`pointer-events-auto bg-[#111] border border-white/10 rounded-xl shadow-2xl w-80 sm:w-96 mb-4 overflow-hidden transition-all duration-300 origin-bottom-right ${
          isOpen ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-10 pointer-events-none'
        }`}
        style={{ maxHeight: '600px', boxShadow: '0 0 40px rgba(0,0,0,0.5)' }}
      >
        {/* Header - Terminal Style */}
        <div className="bg-[#0a0a0a] border-b border-white/5 p-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-red-500"></div>
            <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
            <div className="w-2 h-2 rounded-full bg-green-500"></div>
            <span className="ml-2 font-mono text-xs text-secondary">hector_ai_agent.exe</span>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="text-secondary hover:text-white transition-colors"
          >
            <i className="fa-solid fa-times"></i>
          </button>
        </div>

        {/* Messages */}
        <div className="h-80 overflow-y-auto p-4 space-y-4 font-mono text-sm bg-black/40">
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[85%] px-3 py-2 border ${
                  msg.role === 'user' 
                    ? 'bg-white/5 border-white/20 text-white rounded-lg' 
                    : 'bg-transparent border-transparent text-secondary pl-0'
                }`}
              >
                 {msg.role === 'model' && <span className="text-accent mr-2">{'>'}</span>}
                {msg.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start text-accent pl-4">
              <span className="animate-pulse">_escribiendo...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-3 bg-[#0a0a0a] border-t border-white/5">
          <div className="relative flex items-center gap-2">
            <span className="text-accent font-mono">{'>'}</span>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Escribe un comando..."
              className="w-full bg-transparent text-white text-sm font-mono focus:outline-none placeholder:text-gray-700"
            />
            <button 
              onClick={handleSend}
              disabled={isLoading || !inputValue.trim()}
              className="text-secondary hover:text-white transition-colors disabled:opacity-30"
            >
              <i className="fa-solid fa-paper-plane text-xs"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Toggle Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="pointer-events-auto bg-white hover:bg-accent text-black w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-xl transition-all hover:scale-110 active:scale-95 group z-50"
      >
        <i className={`fa-solid ${isOpen ? 'fa-terminal' : 'fa-robot'} transition-transform duration-300`}></i>
      </button>
    </div>
  );
};

export default AIChat;