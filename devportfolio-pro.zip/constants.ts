
import { Project, Skill, SocialLink, Language } from './types';

export const PROFILE = {
  name: "Hector",
  email: "contacto@hector.dev"
};

export const TRANSLATIONS = {
  es: {
    nav: {
      home: "Inicio",
      work: "Proyectos",
      about: "Sobre Mí",
      contact: "Contacto"
    },
    hero: {
      greeting: `Hola, soy ${PROFILE.name}`,
      role_prefix: "Desarrollador",
      role_suffix: "Full Stack & IA",
      description: "Diseñando interfaces minimalistas e inteligencia artificial para la web del futuro.",
      status: "Abierto a conversaciones interesantes",
      tech_stack: "Arsenal Técnico",
      location: "Base de operaciones",
      focus_label: "Enfoque",
      focus_value: "Arquitectura & IA",
      contact_me: "Contáctame"
    },
    about: {
      title: "Sobre Mí",
      subtitle: "Mi Trayectoria",
      bio_p1: "Soy un desarrollador Full Stack apasionado por la intersección entre el diseño de software robusto y la inteligencia artificial. Mi objetivo es crear experiencias digitales que no solo funcionen a la perfección, sino que también se sientan intuitivas y modernas.",
      bio_p2: "Con experiencia tanto en el ecosistema Java (Spring Boot) como en el moderno stack de JavaScript (React, Next.js) y Python para IA, tengo la capacidad de llevar un producto desde la concepción de la base de datos hasta la interfaz final pixel-perfect.",
      stats: {
        exp: "Años de Exp.",
        projects: "Proyectos",
        commits: "Commits"
      }
    },
    work: {
      title: "Proyectos",
      subtitle: "Seleccionados"
    },
    contact: {
      title: "Vamos a construir algo",
      title_accent: "increíble",
      text: "¿Tienes una idea innovadora o necesitas un desarrollador que entienda tanto de diseño como de código? Estoy a un mensaje de distancia.",
      cta: "Iniciar Conversación",
      copyright: "Diseñado con"
    },
    time: {
      format: 'es-ES'
    }
  },
  en: {
    nav: {
      home: "Home",
      work: "Work",
      about: "About",
      contact: "Contact"
    },
    hero: {
      greeting: `Hi, I'm ${PROFILE.name}`,
      role_prefix: "Full Stack",
      role_suffix: "Developer & AI",
      description: "Designing minimalist interfaces and artificial intelligence for the web of the future.",
      status: "Open to interesting conversations",
      tech_stack: "Tech Stack",
      location: "Base of operations",
      focus_label: "Focus",
      focus_value: "Architecture & AI",
      contact_me: "Contact Me"
    },
    about: {
      title: "About Me",
      subtitle: "My Journey",
      bio_p1: "I am a Full Stack Developer passionate about the intersection of robust software design and artificial intelligence. My goal is to create digital experiences that not only work perfectly but also feel intuitive and modern.",
      bio_p2: "With experience in both the Java ecosystem (Spring Boot) and the modern JavaScript stack (React, Next.js) plus Python for AI, I have the ability to take a product from database conception to the final pixel-perfect interface.",
      stats: {
        exp: "Years Exp.",
        projects: "Projects",
        commits: "Commits"
      }
    },
    work: {
      title: "Selected",
      subtitle: "Projects"
    },
    contact: {
      title: "Let's build something",
      title_accent: "amazing",
      text: "Have an innovative idea or need a developer who understands both design and code? I'm just a message away.",
      cta: "Start Conversation",
      copyright: "Designed with"
    },
    time: {
      format: 'en-US'
    }
  }
};

export const SYSTEM_PROMPT = `Eres el asistente virtual del portafolio de ${PROFILE.name}.
Tu objetivo es responder preguntas sobre la experiencia, habilidades y proyectos de ${PROFILE.name} de manera profesional pero amigable.`;

export const SKILLS: Skill[] = [
  { name: "HTML / CSS", icon: "fa-brands fa-html5", level: 98, category: "frontend" },
  { name: "Angular", icon: "fa-brands fa-angular", level: 85, category: "frontend" },
  { name: "React / Next.js", icon: "fa-brands fa-react", level: 95, category: "frontend" },
  { name: "TypeScript", icon: "fa-brands fa-js", level: 90, category: "frontend" },
  { name: "Spring Boot", icon: "fa-brands fa-java", level: 85, category: "backend" },
  { name: "Node.js", icon: "fa-brands fa-node", level: 85, category: "backend" },
  { name: "Python / AI", icon: "fa-brands fa-python", level: 90, category: "backend" },
  { name: "AWS", icon: "fa-brands fa-aws", level: 80, category: "tools" },
  { name: "Azure", icon: "fa-brands fa-microsoft", level: 80, category: "tools" },
  { name: "Tailwind CSS", icon: "fa-solid fa-wind", level: 95, category: "frontend" },
  { name: "TensorFlow / PyTorch", icon: "fa-solid fa-brain", level: 80, category: "backend" },
  { name: "PostgreSQL", icon: "fa-solid fa-database", level: 85, category: "backend" },
  { name: "Docker", icon: "fa-brands fa-docker", level: 75, category: "tools" },
  { name: "LangChain / LLMs", icon: "fa-solid fa-robot", level: 85, category: "tools" },
];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: "E-Commerce Dashboard",
    description: {
      es: "Plataforma de gestión de inventario y ventas en tiempo real con análisis predictivo.",
      en: "Real-time inventory and sales management platform with predictive analytics."
    },
    tags: ["React", "Node.js", "PostgreSQL", "Recharts"],
    link: "#",
    github: "#",
    images: [
      "https://picsum.photos/seed/dash1/800/600",
      "https://picsum.photos/seed/dash2/800/600",
      "https://picsum.photos/seed/dash3/800/600"
    ]
  },
  {
    id: 2,
    title: "AI Content Generator",
    description: {
      es: "Aplicación SaaS que utiliza LLMs para generar contenido de marketing automatizado.",
      en: "SaaS application utilizing LLMs to generate automated marketing content."
    },
    tags: ["Next.js", "Generative AI", "Tailwind", "Stripe"],
    link: "#",
    github: "#",
    images: [
      "https://picsum.photos/seed/ai1/800/600",
      "https://picsum.photos/seed/ai2/800/600"
    ]
  },
  {
    id: 3,
    title: "TaskFlow Mobile",
    description: {
      es: "Aplicación progresiva (PWA) para gestión de tareas colaborativas.",
      en: "Progressive Web App (PWA) for collaborative task management."
    },
    tags: ["React Native", "Firebase", "Redux"],
    link: "#",
    github: "#",
    images: [
      "https://picsum.photos/seed/task1/800/600",
      "https://picsum.photos/seed/task2/800/600",
      "https://picsum.photos/seed/task3/800/600"
    ]
  }
];

export const SOCIALS: SocialLink[] = [
  { platform: "GitHub", url: "https://github.com", icon: "fa-brands fa-github" },
  { platform: "LinkedIn", url: "https://linkedin.com", icon: "fa-brands fa-linkedin" },
];
