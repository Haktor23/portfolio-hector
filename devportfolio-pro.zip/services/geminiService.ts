import { SYSTEM_PROMPT } from "../constants";

// Generic AI Service Interface
// This service has been decoupled from specific providers (like Gemini) to remain vendor-agnostic in the portfolio display.

export const sendMessageToAI = async (
  message: string,
  history: { role: string; parts: { text: string }[] }[]
): Promise<string> => {
  
  // Implementation for a generic AI backend would go here.
  // Currently set to a placeholder or connected to a custom backend as needed.
  
  if (!process.env.API_KEY) {
    console.warn("API Key is missing for AI Service.");
    return "El servicio de IA no está configurado actualmente.";
  }

  try {
     // Placeholder logic or call to a different LLM
     // For now, we return a standard unavailable message since we removed the specific SDK
     return "El asistente de IA está en mantenimiento. Por favor contáctame por email.";

  } catch (error) {
    console.error("Error communicating with AI Service:", error);
    return "Hubo un error temporal al conectar con mis servidores.";
  }
};